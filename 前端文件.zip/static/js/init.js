// 线上的URL
// baseUrl="http://114.116.244.115:7001"
baseUrl="http://114.116.244.115:8000"
// 本地测试django_URL
//baseUrl="http://127.0.0.1:8000"
// 本地测试nginx_URL
NbaseUrl="http://127.0.0.1"
